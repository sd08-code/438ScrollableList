package com.example.picturelist

// Each item pairs one image with its description.
data class PictureItem(val image: Int, val description: Int)

val pictures = listOf(
    PictureItem(R.drawable.mountains, R.string.caption_mountains),
    PictureItem(R.drawable.beach, R.string.caption_beach),
    PictureItem(R.drawable.forest, R.string.caption_forest),
    PictureItem(R.drawable.city, R.string.caption_city),
    PictureItem(R.drawable.desert, R.string.caption_desert),
    PictureItem(R.drawable.waterfall, R.string.caption_waterfall),
    PictureItem(R.drawable.park, R.string.caption_park),
    PictureItem(R.drawable.winter, R.string.caption_winter),
    PictureItem(R.drawable.lighthouse, R.string.caption_lighthouse),
    PictureItem(R.drawable.fields, R.string.caption_fields)
)
