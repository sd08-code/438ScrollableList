Picture List - CSC 438

Converts the previous slideshow into a simple scrollable list of ten images
and descriptions, using Jetpack Compose LazyColumn.

MainActivity.kt displays the list and image cards.
PictureItem.kt contains the data class and the ten list items.
Images are local vector illustrations. The custom app icon is a gallery image
with mountains and a sun, on a teal background.

To run: extract PictureList-project.zip, open the PictureList folder in
Android Studio, wait for Gradle sync, and click Run with an emulator selected.
Minimum Android version: 7.0 (API 24).
